var c = require('./common');

exports.a = 1;
exports.b = c;
