var c = require('./common');

module.exports = c + 2;