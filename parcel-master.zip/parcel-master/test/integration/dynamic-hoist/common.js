module.exports = require('./common-dep');
