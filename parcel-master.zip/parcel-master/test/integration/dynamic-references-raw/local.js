import raw from './test.txt';

exports.a = 1;
exports.b = 2;
