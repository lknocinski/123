module.exports = function () {
  return process.env.NODE_ENV;
};
