import * as local from './local';
import url from 'url';

export default function () {
  return local.a + local.b;
};
