module.exports = require('fs').readFileSync(__dirname + '/test.txt', 'utf8');
