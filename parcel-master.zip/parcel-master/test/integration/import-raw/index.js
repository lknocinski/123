const url = require('./test.txt');

module.exports = function () {
  return url;
};
