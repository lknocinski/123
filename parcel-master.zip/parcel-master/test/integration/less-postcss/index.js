var map = require('./index.less');

module.exports = function () {
  return map.index;
};
