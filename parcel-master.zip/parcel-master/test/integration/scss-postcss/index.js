var map = require('./index.scss');

module.exports = function () {
  return map.index;
};
