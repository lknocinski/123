var map = require('./index.styl');

module.exports = function () {
  return map.index;
};
