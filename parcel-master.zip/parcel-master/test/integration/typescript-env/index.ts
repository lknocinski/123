export function env() {
  return process.env.NODE_ENV;
}